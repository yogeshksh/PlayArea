﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CSTest;
using Rhino.Mocks;
using System.Collections.Generic;

namespace CSTestUnitTest
{
    [TestClass]
    public class EquityOrderUnitTest
    {
        [TestMethod]
        public void TestReceiveTickWhenPriceIsBelowThresholdAnOrderPlaced()
        {
            //arrange
            List<string> receivedEvents = new List<string>();
            var stubOrderService = MockRepository.GenerateStub<IOrderService>();
            stubOrderService.Stub(s => s.Buy("Test1", 1, 1.0m));
            IEquityOrder eqOrder = new EquityOrder(stubOrderService);
            eqOrder.OrderPlaced += delegate (OrderPlacedEventArgs e)
            {
                receivedEvents.Add(e.EquityCode);
            };

            //act
            eqOrder.ReceiveTick("Test1", 1.0m);

            //assert
            stubOrderService.AssertWasCalled(s => s.Buy("Test1", 1, 1.0m));
            Assert.AreEqual(1, receivedEvents.Count);
            Assert.AreEqual("Test1", receivedEvents[0]);
        }

        [TestMethod]
        public void TestReceiveTickWhenPriceIsAboveThresholdAnOrderIsnotPlaced()
        {
            //arrange
            List<string> receivedEvents = new List<string>();
            var stubOrderService = MockRepository.GenerateStub<IOrderService>();
            stubOrderService.Stub(s => s.Buy("Test1", 1, 2.0m));
            IEquityOrder eqOrder = new EquityOrder(stubOrderService);
            eqOrder.OrderPlaced += delegate (OrderPlacedEventArgs e)
            {
                receivedEvents.Add(e.EquityCode);
            };

            //act
            eqOrder.ReceiveTick("Test1", 2.0m);

            //assert
            stubOrderService.AssertWasNotCalled(s => s.Buy("Test1", 1, 1.0m));
            Assert.AreEqual(0, receivedEvents.Count);

        }

        [TestMethod]
        public void TestReceiveTickWhenErrorOccurredAndOrderErroredEventRaised()
        {
            //arrange
            List<string> receivedEvents = new List<string>();
            IEquityOrder eqOrder = new EquityOrder(null);
            eqOrder.OrderErrored += delegate (OrderErroredEventArgs e)
            {
                receivedEvents.Add(e.EquityCode);
            };

            //act
            eqOrder.ReceiveTick("Test1", 1.0m);

            //assert
            Assert.AreEqual(1, receivedEvents.Count);
            Assert.AreEqual("Test1", receivedEvents[0]);
        }

        [TestMethod]
        public void TestReceiveTickOnlyOneOrderCanBePlaced()
        {
            //arrange
            List<string> receivedEvents = new List<string>();
            var stubOrderService = MockRepository.GenerateStub<IOrderService>();
            stubOrderService.Stub(s => s.Buy("Test1", 1, 1.0m));
            IEquityOrder eqOrder = new EquityOrder(stubOrderService);
            eqOrder.OrderPlaced += delegate (OrderPlacedEventArgs e)
            {
                receivedEvents.Add(e.EquityCode);
            };

            //act
            eqOrder.ReceiveTick("Test1", 1.0m);
            eqOrder.ReceiveTick("Test1", 1.0m);
            eqOrder.ReceiveTick("Test1", 1.0m);
            eqOrder.ReceiveTick("Test1", 1.0m);

            //assert
            stubOrderService.AssertWasCalled(s => s.Buy("Test1", 1, 1.0m));
            Assert.AreEqual(1, receivedEvents.Count);
            Assert.AreEqual("Test1", receivedEvents[0]);

        }
    }


}

