﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSTest
{
    public class OrderService : IOrderService
    {
        public void Buy(string equityCode, int quantity, decimal price)
        {
            throw new NotImplementedException();
        }

        public void Sell(string equityCode, int quantity, decimal price)
        {
            throw new NotImplementedException();
        }
    }
}
