﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSTest
{
    public interface IEquityOrder : IOrderPlaced, IOrderErrored
    {
        void ReceiveTick(string equityCode, decimal price);
    }

}
