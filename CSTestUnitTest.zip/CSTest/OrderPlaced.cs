﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSTest
{
    public delegate void OrderPlacedEventHandler(OrderPlacedEventArgs e);

    public interface IOrderPlaced
    {
        event OrderPlacedEventHandler OrderPlaced;
    }
    public class OrderPlacedEventArgs
    {
        public string EquityCode { get; }
        public decimal Price { get; }

        public OrderPlacedEventArgs(string equityCode, decimal price)
        {
            EquityCode = equityCode;
            Price = price;
        }
    }
   

}
