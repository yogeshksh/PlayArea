﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSTest
{
    public interface IOrderService
    {
        void Buy(string equityCode, int quantity, decimal price);
        void Sell(string equityCode, int quantity, decimal price);
    }
}
