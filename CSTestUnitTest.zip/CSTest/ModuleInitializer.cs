﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSTest
{
    public static class ModuleInitializer
    {
        public static void Initialize()
        {
            DIContainer.Register<IEquityOrder, EquityOrder>();
            DIContainer.Register<IOrderService, OrderService>();
            DIContainer.AddExtension<DependencyOfDependencyExtension>();
        }
    }
}
