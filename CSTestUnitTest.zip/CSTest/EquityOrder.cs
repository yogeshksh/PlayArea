﻿using System;
using System.Collections.Concurrent;

namespace CSTest
{
    public class EquityOrder : IEquityOrder, IDisposable
    {
        // Create an event for each interface event
        private event OrderPlacedEventHandler _orderPlacedEvent;
        private event OrderErroredEventHandler _orderErroredEvent;
        private volatile object objectLock = new Object();

        private IOrderService _orderService;
        private ConcurrentDictionary<string, decimal> _thresholdDictionary;

        public EquityOrder(IOrderService orderService)
        {
            _orderService = orderService;
            _thresholdDictionary = new ConcurrentDictionary<string, decimal>();
            //poulate thresholddictionary for equitycodes;

            _thresholdDictionary.TryAdd("Test1", 1.5m);
            _thresholdDictionary.TryAdd("Test2", 5.0m);

        }
        public event OrderPlacedEventHandler OrderPlaced
        {
            add
            {
                lock (objectLock)
                {
                    _orderPlacedEvent += value;
                }
            }
            remove
            {
                lock (objectLock)
                {
                    _orderPlacedEvent -= value;
                }
            }
        }
        public event OrderErroredEventHandler OrderErrored
        {
            add
            {
                lock (objectLock)
                {
                    _orderErroredEvent += value;
                }
            }
            remove
            {
                lock (objectLock)
                {
                    _orderErroredEvent -= value;
                }
            }

        }

        public void ReceiveTick(string equityCode, decimal price)
        {

            try
            {
                //check the price 
                if (_thresholdDictionary.TryGetValue(equityCode, out decimal threshold))
                {
                    if (price < threshold )
                    {
                        _orderService.Buy(equityCode, 1, price);

                        if (_orderPlacedEvent !=null)
                        {
                            _orderPlacedEvent.Invoke(new OrderPlacedEventArgs(equityCode, price));
                        }
                        return;
                    }
                }

            }
            catch (Exception ex)
            {
                if (_orderErroredEvent !=null)
                {
                    _orderErroredEvent.Invoke(new OrderErroredEventArgs(equityCode, price, ex));
                }
            }
            finally
            {
                _orderErroredEvent = null;
                _orderPlacedEvent = null;
                _orderService =null;
            }
        }

        #region IDisposable Support
        private bool disposedValue = false; 

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    _orderErroredEvent = null;
                    _orderPlacedEvent = null;
                    _orderService = null;
                }

                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}
